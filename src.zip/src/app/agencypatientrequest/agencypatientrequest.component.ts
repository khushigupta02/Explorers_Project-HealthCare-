import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agencypatientrequest',
  templateUrl: './agencypatientrequest.component.html',
  styleUrls: ['./agencypatientrequest.component.css']
})
export class AgencypatientrequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
