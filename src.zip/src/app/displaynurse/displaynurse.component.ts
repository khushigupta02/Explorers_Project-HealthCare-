import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-displaynurse',
  templateUrl: './displaynurse.component.html',
  styleUrls: ['./displaynurse.component.css']
})
export class DisplaynurseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
  