import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agencylogin',
  templateUrl: './agencylogin.component.html',
  styleUrls: ['./agencylogin.component.css']
})
export class AgencyloginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
