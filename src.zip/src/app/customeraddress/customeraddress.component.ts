import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customeraddress',
  templateUrl: './customeraddress.component.html',
  styleUrls: ['./customeraddress.component.css']
})
export class CustomeraddressComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
