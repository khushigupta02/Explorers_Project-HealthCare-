import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footerback',
  templateUrl: './footerback.component.html',
  styleUrls: ['./footerback.component.css']
})
export class FooterbackComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
