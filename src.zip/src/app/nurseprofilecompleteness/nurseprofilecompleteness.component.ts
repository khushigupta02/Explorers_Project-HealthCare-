import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nurseprofilecompleteness',
  templateUrl: './nurseprofilecompleteness.component.html',
  styleUrls: ['./nurseprofilecompleteness.component.css']
})
export class NurseprofilecompletenessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
