import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nurseprofile',
  templateUrl: './nurseprofile.component.html',
  styleUrls: ['./nurseprofile.component.css']
})
export class NurseprofileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
