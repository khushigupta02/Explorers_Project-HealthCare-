import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agencynursedetails',
  templateUrl: './agencynursedetails.component.html',
  styleUrls: ['./agencynursedetails.component.css']
})
export class AgencynursedetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
