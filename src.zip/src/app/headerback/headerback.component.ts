import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-headerback',
  templateUrl: './headerback.component.html',
  styleUrls: ['./headerback.component.css']
})
export class HeaderbackComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
