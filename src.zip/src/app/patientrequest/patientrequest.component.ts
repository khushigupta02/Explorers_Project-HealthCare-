import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patientrequest',
  templateUrl: './patientrequest.component.html',
  styleUrls: ['./patientrequest.component.css']
})
export class PatientrequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
